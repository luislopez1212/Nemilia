// content.js — Nemilia Extension v2.2.0
(function() {
  const META = 'nemilia-ai-workspace';
  if (document.documentElement.dataset.nemInjected) return;
  document.documentElement.dataset.nemInjected = '1';
  let _announced = false;
  function announceReady() {
    if (_announced) return;
    if (document.querySelector('meta[name="application-name"]')?.content !== META) return;
    _announced = true;
    chrome.runtime.sendMessage({type:'NEMILIA_IDENTIFIED', url:window.location.href});
    window.postMessage({type:'NEMILIA_EXT_PING'}, '*');
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', announceReady);
  } else {
    announceReady();
  }
  window.addEventListener('message', function(e) {
    if (e.source !== window) return;
    if (!e.data || !chrome.runtime?.id) return;
    // [SEC] Validate origin — file:// reports 'null', localhost and nemilia.com are explicit
    var _o = e.origin || '';
    if (_o !== 'null' && _o !== 'https://nemilia.com' &&
        !/^https?:\/\/(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?$/.test(_o)) return;
    if (e.data.type === 'NEMILIA_SYNC_WORKFLOWS') {
      chrome.runtime.sendMessage({type:'SYNC_WORKFLOWS', workflows:e.data.workflows});
    }
    // [FIX v2.2] Forward app-ready signal to background so it drains the queue only
    // after the app's message listener is fully wired up (both _initComplete and
    // _authComplete set), preventing items from being fired into the void and wiped.
    if (e.data.type === 'NEMILIA_APP_READY') {
      chrome.runtime.sendMessage({type:'NEMILIA_APP_READY'});
    }
    if (e.data.type === 'NEMILIA_MCP_RELAY') {
      const reqId = e.data.reqId;
      chrome.runtime.sendMessage({
        type:'MCP_RELAY', url:e.data.url, method:e.data.method,
        headers:e.data.headers, body:e.data.body
      }, function(response) {
        window.postMessage({type:'NEMILIA_MCP_RELAY_RESPONSE', reqId, response}, '*');
      });
    }
    if (e.data.type === 'NEMILIA_API_STREAM_START') {
      const _reqId = e.data.reqId;                          // [H1] isolate by reqId
      const _asrPort = chrome.runtime.connect({ name: 'nemilia-api-stream' });
      let _streamDone = false;                              // [H2] track completion
      _asrPort.onMessage.addListener(function(msg) {
        if (msg.type === 'API_STREAM_DONE' || msg.type === 'API_STREAM_ERROR') {
          _streamDone = true;
        }
        window.postMessage(Object.assign({ _src: 'nemilia-api-stream', _reqId }, msg), '*');
      });
      _asrPort.onDisconnect.addListener(function() {
        // [H2] only fire ERROR if stream didn't finish cleanly — handles service worker killed mid-stream
        if (!_streamDone) {
          window.postMessage({
            _src: 'nemilia-api-stream', _reqId,
            type: 'API_STREAM_ERROR',
            error: 'Extension service worker disconnected mid-stream — please retry'
          }, '*');
        }
      });
      _asrPort.postMessage({
        type:'API_STREAM_START', reqId:_reqId,             // [H1] pass reqId to bg
        url:e.data.url, method:e.data.method,
        headers:e.data.headers, body:e.data.body
      });
    }
  });
})();
