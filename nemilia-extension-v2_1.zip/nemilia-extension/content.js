// content.js — Nemilia Extension v2.1.0
(function() {
  const META = 'nemilia-ai-workspace';
  if (document.querySelector('meta[name="application-name"]')?.content === META) {
    // FIX v1.3.2: removed direct captureQueue drain here — background.js owns
    // queue delivery via tabs.onUpdated → drainQueue → postMessage, so Nemilia's
    // _initComplete guard can hold items until loadLS() has settled WS.captured.
    chrome.runtime.sendMessage({type:'NEMILIA_IDENTIFIED', url:window.location.href});
    window.postMessage({type:'NEMILIA_EXT_PING'}, '*');
  }
  window.addEventListener('message', function(e) {
    if (e.data?.type === 'NEMILIA_SYNC_WORKFLOWS' && chrome.runtime?.id) {
      chrome.runtime.sendMessage({type:'SYNC_WORKFLOWS', workflows:e.data.workflows});
    }
  });
})();
