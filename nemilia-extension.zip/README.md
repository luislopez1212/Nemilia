# Nemilia — Send to Workspace

Chrome extension companion for **Nemilia AI Workspace v2.2** — the AI OS for your browser.

Captures any page, image, or screenshot and delivers it to your Nemilia workspace. Triggers AI workflows from any site without leaving your current tab. Routes MCP server calls through the extension to bypass CORS restrictions when running Nemilia as a local file.

---

## Requirements

This extension only works alongside the **Nemilia AI Workspace** application (`Nemilia_v2_2.html`). Download it from the same GitHub release or at [nemilia.com](https://nemilia.com).

---

## Installation

1. Unzip `nemilia-extension-v2_2.zip` anywhere on your machine
2. Open `chrome://extensions` in Chrome
3. Enable **Developer mode** (toggle, top right)
4. Click **Load unpacked** → select the `nemilia-extension` folder
5. Open the extension **Details** → enable **Allow access to file URLs**
6. Pin the extension from the 🧩 toolbar icon for quick access

Once installed, open Nemilia — the green **● Extension connected** badge appears in Settings confirming the connection.

---

## What It Does

**Right-click any page:**
- **Quick Capture** — extracts full page text and sends to your Captures inbox
- **Open in Compose** — sends page content directly to Nemilia's Compose view
- **Capture Screenshot** — takes a screenshot of the visible tab and sends for vision analysis
- **Run Workflow →** — submenu lists your saved workflows; select one to run it against the page instantly

**Right-click any image:**
- **Send Image to Nemilia** — sends the image directly to your Captures inbox for vision analysis

**Extension popup (click toolbar icon):**
- **Send Full Page** — captures full page text
- **Send Selection** — captures highlighted text only
- **Capture Screenshot** — captures the visible tab

**Offline queue:** If Nemilia isn't open, items are saved locally and delivered automatically the next time Nemilia opens.

**MCP relay:** When Nemilia is running as a local file (`file://`), the browser blocks outbound requests to external MCP servers due to CORS restrictions. The extension automatically relays those requests through its background service worker, which is not subject to CORS. This requires no configuration — it activates automatically whenever the extension is connected.

---

## MCP Server Requirements

The extension relay supports **streamable HTTP** (MCP spec 2024-11-05+) and **plain HTTP** transports. These cover all servers in the Nemilia catalog and the majority of custom servers.

**SSE transport is deprecated and not supported via the relay.** SSE (Server-Sent Events) is a legacy MCP transport no longer recommended by the MCP specification. Servers using SSE transport will not work when Nemilia is running from a local file. If you are connecting a custom server that only supports SSE, contact the server provider about upgrading to streamable HTTP.

When you add or test an MCP server, Nemilia automatically detects the transport type. Servers detected as SSE will show a warning in the Connections panel.

---

## Privacy

This extension does not collect, transmit, or store any data on external servers. Captured content and MCP traffic is sent only between your browser and the servers you have explicitly configured — it never passes through Nemilia servers. No analytics, no tracking, no third-party data sharing of any kind.

---

## Permissions

| Permission | Why |
|-----------|-----|
| `activeTab` | Access the current tab to extract text and capture screenshots on user action |
| `scripting` | Inject script to read page text for capture — read only, no page modification |
| `storage` | Persist offline capture queue and sync workflow list |
| `tabs` | Locate the open Nemilia tab to deliver captured items |
| `contextMenus` | Add right-click capture and workflow options to all pages |
| `host_permissions` | Capture content from any page the user chooses; `file://` required for local Nemilia app communication; `*://*/*` required for MCP relay to reach external servers |

---

## What's New in v2.2

The companion **Nemilia AI Workspace v2.2** ships a set of universal reliability and transparency upgrades that work regardless of provider (cloud or local) or hardware:

**Adaptive context budgeting**
- Removes arbitrary token/char ceilings (`CHARS_PER_TOK=4`, `0.5 × ctx` output reserve, `Math.max(4096, …)` floors)
- Per-model rolling measurements (`chars/token`, `prompt tokens/sec`) stored as an EMA over the last ~10 requests
- RAG char budget derived purely from context math: `(ctx − userMaxOut − 256) × measuredCpt`
- RAG topK derived from the document's actual average chunk size, not a magic `2000`

**Pre-send transparency chip**
- A small indicator next to the Send button shows `~N tok in · est {time} to first token` for local providers, `~N tok in` for cloud
- First run on a new model shows `first run (no timing data yet)` and self-corrects after one call
- No auto-abort, no patience knob — the Stop button is always the cancel mechanism

**Vision retry-on-failure with canvas normalization**
- First attempt sends the original image untouched — no unnecessary re-encoding for images that already work
- If the server rejects with `Invalid image`, `unsupported`, `decode`, or a size/payload error, Nemilia retries once with a canvas-normalized JPEG (quality 0.92) that flattens palette, indexed, 16-bit, CMYK, and ICC-tagged PNGs into a format strict C decoders (llama.cpp / stb_image) accept
- Per-provider `visionMaxBase64Bytes` is learned from any `413` / "too large" response and used to auto-downscale future images — no hardcoded dimension cap
- Vision `max_tokens` now honors your Max Tokens preference instead of a hardcoded `2000`

**Pending-vision send defer**
- Attached images show a pulsing `Analyzing image…` ring on their chip while vision analysis runs
- Clicking Send while any attachment is still analyzing shows `Waiting for image analysis… (N remaining)` with a **Send anyway** escape link
- If you choose Send anyway, a note is appended so the model doesn't hallucinate image content
- Eliminates the silent failure where a chip looked ready but the model received no image context

**Brand-logo busy indicator**
- Restores the spinning ring on the top-left logo during streaming, vision processing, and document ingest
- Depth-counted so concurrent jobs (vision queue + chat) keep the indicator on until all clear

**Honest error surfacing**
- `safeOutputBudget` throws an actionable error when input + safety exceed the model's context, instead of silently clamping
- Callers surface `Reduce attachments or raise model ctx` toasts rather than hiding the overflow

**UX polish**
- Image-remove in chat uses `requestAnimationFrame` + forced reflow to eliminate the intermittent viewport truncation race
- No new preferences, no schema migrations — all new fields are absent-tolerant and backward-compatible with v2.1 profiles

---

## Version

**Extension:** v2.2.0
**Compatible with:** Nemilia AI Workspace v2.2
**Manifest:** v3

---

## Links

- **Website:** [nemilia.com](https://nemilia.com)
- **Full documentation:** [github.com/luislopez1212/Nemilia](https://github.com/luislopez1212/Nemilia)
- **Download Nemilia AI Workspace:** [GitHub Releases](https://github.com/luislopez1212/Nemilia/releases)
- **Contact:** [luis@nemilia.com](mailto:luis@nemilia.com)

---

## License

Business Source License 1.1 — free for personal and non-commercial use. Converts to MIT on 2030-02-27.

For commercial licensing: [luis@nemilia.com](mailto:luis@nemilia.com)
