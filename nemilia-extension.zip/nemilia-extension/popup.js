// popup.js — Nemilia Extension v2.2.0 (CSP-compliant: no inline handlers)
'use strict';

var currentTab = null;

var PAGE_SVG = '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5">'
  + '<path d="M4 2h6l4 4v9a1 1 0 01-1 1H3a1 1 0 01-1-1V3a1 1 0 011-1z"/>'
  + '<path d="M10 2v4h4"/></svg>';
var SEL_SVG  = '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5">'
  + '<path d="M2 5h12M2 8h8M2 11h10" stroke-linecap="round"/></svg>';
var SHOT_SVG = '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5">'
  + '<rect x="1" y="3" width="14" height="10" rx="1.5"/><circle cx="8" cy="8" r="2.5"/>'
  + '<path d="M5.5 3V2.5M10.5 3V2.5" stroke-linecap="round"/></svg>';

var PAGE_LABEL = PAGE_SVG + ' Send Full Page';
var SEL_LABEL  = SEL_SVG  + ' Send Selection';
var SHOT_LABEL = SHOT_SVG + ' Capture Screenshot';

// ── Helpers ────────────────────────────────────────────────────────────────
function setst(msg, t) {
  var el = document.getElementById('st');
  el.innerHTML = msg;
  el.className = 'st show ' + (t || 'info');
}

function setbtn(id, loading, label) {
  var b = document.getElementById(id);
  b.disabled = loading;
  b.innerHTML = loading ? '<span class="sp"></span>\u00a0' + label : label;
}

function host(u) {
  try { return new URL(u).hostname || u.slice(0, 40); }
  catch(e) { return (u || '').slice(0, 40); }
}

function done(btnId, origLabel, res) {
  if (!res || !res.ok) {
    setst('\u2717 ' + (res && res.error || 'Failed'), 'err');
    setbtn(btnId, false, origLabel);
    return;
  }
  if (res.queued) {
    setst('\ud83d\udce5 Queued \u2014 open Nemilia to receive', 'info');
    setbtn(btnId, false, '\ud83d\udce5 Queued');
    // Update queue bar in current popup session
    chrome.storage.local.get(['captureQueue'], function(qr) {
      var q = (qr && qr.captureQueue) || [];
      document.getElementById('qcnt').textContent = q.length;
      document.getElementById('qbar').style.display = '';
    });
  } else {
    setst('\u2713 Sent!', 'ok');
    setbtn(btnId, false, '\u2713 Sent');
    setTimeout(function() { window.close(); }, 1000);
  }
}

// ── Init ───────────────────────────────────────────────────────────────────
async function init() {
  var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTab = tabs[0];
  if (!currentTab) { setst('Cannot access current tab', 'err'); return; }

  var ttlEl = document.getElementById('ttl');
  ttlEl.textContent = (currentTab.title || currentTab.url || '').slice(0, 55);
  ttlEl.title = currentTab.url;

  var qr = await chrome.storage.local.get(['captureQueue']);
  var q = qr.captureQueue || [];
  if (q.length) {
    document.getElementById('qcnt').textContent = q.length;
    document.getElementById('qbar').style.display = '';
  }

  chrome.runtime.sendMessage({ type: 'EXTRACT_PAGE', mode: 'meta' }, function(r) {
    document.getElementById('meta').textContent = r && r.ok
      ? (r.data.wordCount || 0).toLocaleString() + ' words \u00b7 ' + host(currentTab.url)
      : host(currentTab.url);
  });
}

// ── Send Full Page ─────────────────────────────────────────────────────────
function sendPage() {
  setbtn('btn-page', true, 'Extracting\u2026');
  setst('Reading page\u2026', 'info');

  chrome.runtime.sendMessage({ type: 'EXTRACT_PAGE', mode: 'page' }, function(r) {
    if (chrome.runtime.lastError) {
      setst('\u2717 ' + chrome.runtime.lastError.message, 'err');
      setbtn('btn-page', false, PAGE_LABEL); return;
    }
    if (!r || !r.ok) {
      setst('\u2717 ' + (r && r.error || 'Extract failed'), 'err');
      setbtn('btn-page', false, PAGE_LABEL); return;
    }
    setbtn('btn-page', true, 'Sending\u2026');
    setst(r.data.truncated ? 'Sending\u2026 (content truncated at 50K chars)' : 'Sending\u2026', 'info');

    var payload = Object.assign(
      { capturedAt: Date.now(), target: 'capture', sourceType: 'page' },
      r.data
    );
    chrome.runtime.sendMessage({ type: 'SEND_TO_NEMILIA', payload: payload }, function(res) {
      if (chrome.runtime.lastError) {
        setst('\u2717 ' + chrome.runtime.lastError.message, 'err');
        setbtn('btn-page', false, PAGE_LABEL); return;
      }
      done('btn-page', PAGE_LABEL, res);
    });
  });
}

// ── Capture Screenshot ─────────────────────────────────────────────────────
function sendShot() {
  setbtn('btn-shot', true, 'Capturing\u2026');
  setst('Capturing screenshot\u2026', 'info');
  chrome.tabs.captureVisibleTab(null, { format: 'png' }, function(dataUrl) {
    if (chrome.runtime.lastError || !dataUrl) {
      setst('\u2717 ' + (chrome.runtime.lastError?.message || 'Screenshot failed'), 'err');
      setbtn('btn-shot', false, SHOT_LABEL); return;
    }
    setbtn('btn-shot', true, 'Sending\u2026');
    var payload = {
      title: (currentTab.title || currentTab.url || 'Screenshot').slice(0, 80),
      url: currentTab.url || '',
      content: '',
      summary: 'Screenshot of ' + (currentTab.title || currentTab.url || 'page'),
      language: 'en',
      wordCount: 0,
      capturedAt: Date.now(),
      target: 'screenshot',
      sourceType: 'screenshot',
      dataUrl: dataUrl
    };
    chrome.runtime.sendMessage({ type: 'SEND_TO_NEMILIA', payload: payload }, function(res) {
      if (chrome.runtime.lastError) {
        setst('\u2717 ' + chrome.runtime.lastError.message, 'err');
        setbtn('btn-shot', false, SHOT_LABEL); return;
      }
      done('btn-shot', SHOT_LABEL, res);
    });
  });
}

// ── Send Selection ─────────────────────────────────────────────────────────
function sendSel() {
  setbtn('btn-sel', true, 'Getting selection\u2026');
  setst('Reading selection\u2026', 'info');

  chrome.runtime.sendMessage({ type: 'EXTRACT_PAGE', mode: 'selection' }, function(r) {
    if (chrome.runtime.lastError) {
      setst('\u2717 ' + chrome.runtime.lastError.message, 'err');
      setbtn('btn-sel', false, SEL_LABEL); return;
    }
    if (!r || !r.ok) {
      setst(
        r && r.error === 'No text selected'
          ? 'Highlight text on the page first'
          : '\u2717 ' + (r && r.error || 'Failed'),
        'err'
      );
      setbtn('btn-sel', false, SEL_LABEL); return;
    }
    setbtn('btn-sel', true, 'Sending\u2026');

    var payload = {
      title:      r.data.title,
      url:        currentTab.url || '',
      content:    r.data.content,
      summary:    (r.data.content || '').slice(0, 280),
      language:   'en',
      wordCount:  r.data.wordCount || 0,
      capturedAt: Date.now(),
      target:     'capture',
      sourceType: 'selection'
    };
    chrome.runtime.sendMessage({ type: 'SEND_TO_NEMILIA', payload: payload }, function(res) {
      if (chrome.runtime.lastError) {
        setst('\u2717 ' + chrome.runtime.lastError.message, 'err');
        setbtn('btn-sel', false, SEL_LABEL); return;
      }
      done('btn-sel', SEL_LABEL, res);
    });
  });
}

// ── Wire up — addEventListener only, no inline handlers ───────────────────
document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('btn-page').innerHTML = PAGE_LABEL;
  document.getElementById('btn-sel').innerHTML  = SEL_LABEL;
  document.getElementById('btn-shot').innerHTML = SHOT_LABEL;
  document.getElementById('btn-page').addEventListener('click', sendPage);
  document.getElementById('btn-sel').addEventListener('click',  sendSel);
  document.getElementById('btn-shot').addEventListener('click', sendShot);
  init();
});
