// background.js — Nemilia Extension v2.1.0
const NEMILIA_META = 'nemilia-ai-workspace';
const MAX_QUEUE    = 200;
const DEFAULT_WORKFLOWS = [
  {id:'wf-research',    name:'Research Suite'},
  {id:'wf-webresearch', name:'Web Research Suite'},
  {id:'wf-marketing',   name:'Marketing Campaign Brief'},
  {id:'wf-competitive', name:'Competitive Intelligence'},
  {id:'wf-content',     name:'Content Calendar'},
  {id:'wf-invest',      name:'Investment Due Diligence'},
  {id:'wf-prd',         name:'Product Spec / PRD'},
];

async function updateBadge() {
  const {captureQueue=[]} = await chrome.storage.local.get(['captureQueue']);
  const n = captureQueue.length;
  chrome.action.setBadgeText({text: n > 0 ? String(n) : ''});
  chrome.action.setBadgeBackgroundColor({color:'#8b6914'});
}

async function buildContextMenus() {
  await chrome.contextMenus.removeAll();
  const {nemiliaWorkflows} = await chrome.storage.local.get(['nemiliaWorkflows']);
  const wfs = nemiliaWorkflows?.length ? nemiliaWorkflows : DEFAULT_WORKFLOWS;

  // Image context: single flat item — always goes direct to Captures inbox, no submenu
  chrome.contextMenus.create({id:'nem-img-capture', title:'\ud83d\udce5  Send Image to Nemilia', contexts:['image']});

  // Selection and Page: full submenus with Quick Capture, Compose, Screenshot, and workflow list
  ['sel','page'].forEach(ctx => {
    const ctxs = ctx==='sel' ? ['selection'] : ['page','frame','link'];
    const rootTitle = ctx==='sel' ? 'Send Selection to Nemilia \u25b8' : 'Send Page to Nemilia \u25b8';
    chrome.contextMenus.create({id:`nem-${ctx}-root`,       title:rootTitle, contexts:ctxs});
    chrome.contextMenus.create({id:`nem-${ctx}-capture`,    parentId:`nem-${ctx}-root`, title:'\ud83d\udce5  Quick Capture',                      contexts:ctxs});
    chrome.contextMenus.create({id:`nem-${ctx}-compose`,    parentId:`nem-${ctx}-root`, title:'\u270f  Open in Compose',                          contexts:ctxs});
    chrome.contextMenus.create({id:`nem-${ctx}-screenshot`, parentId:`nem-${ctx}-root`, title:'\ud83d\udcf7  Capture Screenshot \u2192 Nemilia',   contexts:ctxs});
    chrome.contextMenus.create({id:`nem-${ctx}-sep`,        parentId:`nem-${ctx}-root`, type:'separator',                                          contexts:ctxs});
    chrome.contextMenus.create({id:`nem-${ctx}-wf-lbl`,     parentId:`nem-${ctx}-root`, title:'\u25b6  Run Workflow\u2026', enabled:false,          contexts:ctxs});
    wfs.forEach(wf => chrome.contextMenus.create({
      id:`nem-${ctx}-wf-${wf.id}`, parentId:`nem-${ctx}-root`,
      title:`   ${wf.name}`, contexts:ctxs
    }));
  });
}

chrome.runtime.onInstalled.addListener(() => { buildContextMenus(); updateBadge(); });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    if (changes.nemiliaWorkflows) buildContextMenus();
    if (changes.captureQueue)     updateBadge();
  }
});

function extractPageContent() {
  const clone = document.body.cloneNode(true);
  ['script','style','noscript','nav','footer','header','aside','iframe','[role="navigation"]']
    .forEach(s => { try { clone.querySelectorAll(s).forEach(el=>el.remove()); } catch(e) {} });
  let text = '';
  for (const sel of ['main','article','[role="main"]','.post-content','#content','#main']) {
    const el = clone.querySelector(sel);
    if (el && (el.innerText||el.textContent||'').trim().length > 200) {
      text = (el.innerText||el.textContent||'').trim(); break;
    }
  }
  if (!text) text = (clone.innerText||clone.textContent||'').trim();
  text = text.replace(/^(skip to (main )?content\n?)/i,'').replace(/\n{3,}/g,'\n\n').replace(/[ \t]+/g,' ').trim();
  const sents = text.match(/[^.!?]+[.!?]+/g) || [];
  return {
    title:     document.title,
    content:   text.slice(0, 50000),
    summary:   sents.slice(0,2).join(' ').slice(0,280),
    wordCount: text.split(/\s+/).filter(Boolean).length
  };
}

// ── Fetch an image URL and convert to base64 dataUrl ─────────────────────
async function fetchImageAsDataUrl(srcUrl) {
  const response = await fetch(srcUrl);
  if (!response.ok) throw new Error('HTTP ' + response.status);
  const mimeType = response.headers.get('content-type')?.split(';')[0]?.trim() || 'image/png';
  const buffer   = await response.arrayBuffer();
  const bytes    = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i += 8192) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
  }
  return 'data:' + mimeType + ';base64,' + btoa(binary);
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const id = info.menuItemId, sel = info.selectionText || '';
  if (id.endsWith('-root') || id.endsWith('-sep') || id.endsWith('-wf-lbl')) return;

  let action = 'capture', workflowId = null;
  if      (id.endsWith('-capture'))    action = 'capture';
  else if (id.endsWith('-compose'))    action = 'compose';
  else if (id.endsWith('-screenshot')) action = 'screenshot';
  else if (id.includes('-wf-'))   { action = 'workflow'; workflowId = id.replace(/nem-(sel|page)-wf-/, ''); }
  else return;

  // ── Image context menu — single flat item, always capture to Captures inbox ──
  if (id === 'nem-img-capture' && info.srcUrl) {
    try {
      const dataUrl  = await fetchImageAsDataUrl(info.srcUrl);
      const filename = info.srcUrl.split('/').pop()?.split('?')[0] || 'image.png';
      const payload  = {
        title:      filename.slice(0, 80),
        url:        tab.url || '',
        content:    '',
        summary:    'Image from ' + (tab.title || tab.url || 'page'),
        language:   'en',
        wordCount:  0,
        capturedAt: Date.now(),
        target:     'capture',
        sourceType: 'direct-image',
        dataUrl
      };
      await handleSend(payload, tab.id);
    } catch(e) { console.warn('Nemilia: image fetch failed', e); }
    return;
  }

  // ── Screenshot capture ──
  if (action === 'screenshot') {
    try {
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
      const payload = {
        title: (tab.title || tab.url || 'Screenshot').slice(0, 80),
        url: tab.url || '',
        content: '',
        summary: 'Screenshot of ' + (tab.title || tab.url || 'page'),
        language: 'en',
        wordCount: 0,
        capturedAt: Date.now(),
        target: 'screenshot',
        sourceType: 'screenshot',
        dataUrl
      };
      await handleSend(payload, tab.id);
    } catch(e) { console.warn('Nemilia: screenshot failed', e); }
    return;
  }

  let payload;
  if (id.startsWith('nem-sel-') && sel) {
    payload = {
      title: sel.slice(0,80) + (sel.length > 80 ? '\u2026' : ''), url: tab.url||'',
      content: sel, summary: sel.slice(0,280), language: 'en',
      wordCount: sel.split(/\s+/).filter(Boolean).length,
      capturedAt: Date.now(), target: action, workflowId, sourceType: 'selection'
    };
  } else {
    try {
      const r = await chrome.scripting.executeScript({ target:{tabId:tab.id}, func: extractPageContent });
      const d = r?.[0]?.result || {};
      payload = {
        title: d.title||tab.title||tab.url, url: tab.url||'',
        content: d.content||'', summary: d.summary||'', language: 'en',
        wordCount: d.wordCount||0, capturedAt: Date.now(),
        target: action, workflowId, sourceType: 'page'
      };
    } catch(e) { console.warn('Nemilia: extract failed', e); return; }
  }
  await handleSend(payload, tab.id);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'SEND_TO_NEMILIA') {
    handleSend(msg.payload, sender.tab?.id)
      .then(r => sendResponse(r))
      .catch(e => sendResponse({ok:false, error:e.message}));
    return true;
  }
  if (msg.type === 'EXTRACT_PAGE') {
    chrome.tabs.query({active:true, currentWindow:true}).then(async tabs => {
      const tab = tabs[0];
      if (!tab) return sendResponse({ok:false, error:'No active tab'});
      try {
        if (msg.mode === 'selection') {
          const r = await chrome.scripting.executeScript({
            target: {tabId:tab.id},
            func: () => window.getSelection()?.toString() || ''
          });
          const raw = r?.[0]?.result || '';
          if (!raw.trim()) return sendResponse({ok:false, error:'No text selected'});
          sendResponse({ok:true, data:{
            title: raw.slice(0,80), url: tab.url||'', content: raw,
            summary: raw.slice(0,280),
            wordCount: raw.split(/\s+/).filter(Boolean).length
          }});
        } else {
          const r = await chrome.scripting.executeScript({
            target: {tabId:tab.id}, func: extractPageContent
          });
          const d = r?.[0]?.result || {};
          sendResponse({ok:true, data:{
            title: d.title||tab.title||'', url: tab.url||'',
            content: d.content||'', summary: d.summary||'',
            wordCount: d.wordCount||0
          }});
        }
      } catch(e) { sendResponse({ok:false, error:e.message}); }
    });
    return true;
  }
  if (msg.type === 'NEMILIA_IDENTIFIED') {
    // FIX v1.4.1: only save path here — drainQueue runs from tabs.onUpdated once
    // the page is complete, preventing double-drain and double-toast.
    chrome.storage.local.set({nemiliaPath: msg.url});
  }
  if (msg.type === 'SYNC_WORKFLOWS') {
    chrome.storage.local.set({nemiliaWorkflows: msg.workflows});
  }
});

// ── Image payload detection ───────────────────────────────────────────────
// Images (screenshots, page-image captures) carry a large base64 dataUrl that must
// NOT be stored in chrome.storage.local (10MB quota — a single screenshot can be 1-3MB).
// When Nemilia is open: postMessage directly, bypassing the queue entirely.
// When Nemilia is NOT open: queue a placeholder without dataUrl so the item still
// arrives as a no-data capture rather than silently failing.
// ── chrome.storage.session availability check (Chrome 102+) ─────────────────
const SESSION_STORAGE_AVAILABLE = !!(chrome.storage && chrome.storage.session);

async function storeImageInSession(key, payload) {
  if (!SESSION_STORAGE_AVAILABLE) return false;
  try {
    await chrome.storage.session.set({[key]: payload});
    return true;
  } catch(e) {
    console.warn('Nemilia: session storage failed:', e.message);
    return false;
  }
}

async function getImageFromSession(key) {
  if (!SESSION_STORAGE_AVAILABLE) return null;
  try {
    const result = await chrome.storage.session.get([key]);
    return result[key] || null;
  } catch(e) { return null; }
}

async function clearImageFromSession(key) {
  if (!SESSION_STORAGE_AVAILABLE) return;
  try { await chrome.storage.session.remove([key]); } catch(e) {}
}

function isImagePayload(payload) {
  return !!(payload.dataUrl && (payload.sourceType === 'screenshot' || payload.sourceType === 'page-image' || payload.sourceType === 'direct-image'));
}

async function handleSend(payload, sourceTabId) {
  const nemTab = await findNemiliaTab();

  // ── Image fast-path ───────────────────────────────────────────────────────
  if (isImagePayload(payload)) {
    if (nemTab) {
      // Nemilia is open — inject directly via postMessage, skip queue entirely
      try {
        await chrome.scripting.executeScript({
          target: {tabId: nemTab.id},
          func: (item) => { window.postMessage({type:'NEMILIA_INGEST', ...item}, '*'); },
          args: [payload]
        });
        await showSourceToast(sourceTabId, nemTab.id, '✓ Image sent to Nemilia');
        return {ok:true, queued:false};
      } catch(e) {
        console.warn('Nemilia: image direct-send failed', e);
        return {ok:false, error:e.message};
      }
    } else {
      // Nemilia not open — store full payload in session storage, queue placeholder
      const sessionKey = 'nem-img-' + Date.now() + '-' + Math.random().toString(36).slice(2,6);
      const stored = await storeImageInSession(sessionKey, payload);
      // Placeholder: no dataUrl, but carries sessionKey so drainQueue can rehydrate
      const placeholder = Object.assign({}, payload);
      delete placeholder.dataUrl;
      if (stored) placeholder.sessionKey = sessionKey;
      await enqueuePayload(placeholder);
      await updateBadge();
      const msg = stored
        ? '📥 Image queued — open Nemilia to receive'
        : '📥 Image queued (session storage unavailable — limited data only)';
      await showSourceToast(sourceTabId, null, msg);
      return {ok:true, queued:true};
    }
  }

  // ── Text/page payloads: normal queue path ────────────────────────────────
  await enqueuePayload(payload);
  await updateBadge();
  if (!nemTab) {
    await showSourceToast(sourceTabId, null, '📥 Saved — open Nemilia to receive');
    return {ok:true, queued:true};
  }
  return drainQueue(nemTab, sourceTabId);
}

async function enqueuePayload(payload) {
  try {
    const {captureQueue=[]} = await chrome.storage.local.get(['captureQueue']);
    const deduped = captureQueue.filter(c => !(c.url===payload.url && c.sourceType!=='selection'));
    deduped.unshift(payload);
    if (deduped.length > MAX_QUEUE) deduped.length = MAX_QUEUE;
    await chrome.storage.local.set({captureQueue: deduped});
  } catch(e) {
    // Storage quota exceeded or other error — log but don't crash
    console.warn('Nemilia: queue storage failed', e.message);
  }
}

async function showSourceToast(sourceTabId, nemTabId, message) {
  if (!sourceTabId || sourceTabId === nemTabId) return;
  try {
    await chrome.scripting.executeScript({
      target: {tabId: sourceTabId},
      func: (msg) => {
        var old = document.getElementById('__nem_toast__');
        if (old) old.remove();
        var t = document.createElement('div');
        t.id = '__nem_toast__';
        Object.assign(t.style, {
          position:'fixed',bottom:'24px',right:'24px',zIndex:'2147483647',
          background:'#1a3040',color:'#c9a84c',padding:'10px 18px',
          borderRadius:'8px',fontFamily:'Inter,system-ui,sans-serif',
          fontSize:'13px',fontWeight:'600',boxShadow:'0 4px 20px rgba(0,0,0,.3)',
          display:'flex',alignItems:'center',gap:'8px',
          borderLeft:'3px solid #c9a84c',transition:'opacity .4s',opacity:'1',
          maxWidth:'320px',lineHeight:'1.4'
        });
        t.innerHTML = '<span style="font-size:16px;flex-shrink:0">📥</span><span>' + msg + '</span>';
        document.body.appendChild(t);
        setTimeout(function(){ t.style.opacity='0'; setTimeout(function(){ if(t.parentNode) t.remove(); }, 450); }, 3500);
      },
      args: [message]
    });
  } catch(e) {}
}

async function findNemiliaTab() {
  const {nemiliaPath} = await chrome.storage.local.get(['nemiliaPath']);
  const tabs = await chrome.tabs.query({});
  if (nemiliaPath) { const t = tabs.find(t=>t.url===nemiliaPath); if(t) return t; }
  const byTitle = tabs.find(t => t.title === 'Nemilia AI Workspace');
  if (byTitle) return byTitle;
  for (const tab of tabs.filter(t => t.url?.startsWith('file://'))) {
    try {
      const r = await chrome.scripting.executeScript({
        target: {tabId:tab.id},
        func: () => document.querySelector('meta[name="application-name"]')?.content
      });
      if (r?.[0]?.result === 'nemilia-ai-workspace') {
        await chrome.storage.local.set({nemiliaPath:tab.url}); return tab;
      }
    } catch(e) {}
  }
  return null;
}

async function drainQueue(nemTab, sourceTabId) {
  const {captureQueue=[]} = await chrome.storage.local.get(['captureQueue']);
  if (!captureQueue.length) return {ok:true, queued:false};

  // Rehydrate any image placeholders that have a sessionKey
  const imageCount = captureQueue.filter(c => c.sessionKey).length;
  const rehydrated = await Promise.all(captureQueue.map(async item => {
    if (!item.sessionKey) return item;
    const full = await getImageFromSession(item.sessionKey);
    if (full) {
      await clearImageFromSession(item.sessionKey);
      return full; // full payload with dataUrl restored
    }
    // Session expired (browser restarted) — return placeholder as-is
    const stripped = Object.assign({}, item);
    delete stripped.sessionKey;
    return stripped;
  }));

  try {
    await chrome.scripting.executeScript({
      target: {tabId:nemTab.id},
      func: (items, imgCount) => {
        var i = 0;
        function sendNext() {
          if (i >= items.length) {
            if (imgCount > 0) {
              window.postMessage({type:'NEMILIA_QUEUE_IMAGES_RECEIVED', count: imgCount}, '*');
            }
            return;
          }
          const item = items[i++];
          window.postMessage({type:'NEMILIA_INGEST', ...item}, '*');
          if (i < items.length) requestAnimationFrame(sendNext);
          else {
            if (imgCount > 0) {
              window.postMessage({type:'NEMILIA_QUEUE_IMAGES_RECEIVED', count: imgCount}, '*');
            }
          }
        }
        sendNext();
      },
      args: [rehydrated, imageCount]
    });
    await chrome.storage.local.set({captureQueue:[]});
    await showSourceToast(sourceTabId, nemTab.id, '✓ Sent to Nemilia');
    await updateBadge();
    return {ok:true, queued:false};
  } catch(e) { return {ok:true, queued:true, error:e.message}; }
}

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  // Only probe file:// tabs — content.js is now injected dynamically, not statically
  if (!tab.url?.startsWith('file://')) return;
  try {
    const r = await chrome.scripting.executeScript({
      target: {tabId},
      func: () => document.querySelector('meta[name="application-name"]')?.content
    });
    if (r?.[0]?.result === 'nemilia-ai-workspace') {
      await chrome.storage.local.set({nemiliaPath:tab.url});
      // Dynamically inject content.js so message relay (NEMILIA_IDENTIFIED, SYNC_WORKFLOWS) works
      // without needing static <all_urls> injection on every page
      await chrome.scripting.executeScript({
        target: {tabId},
        files: ['content.js']
      });
      await drainQueue(tab, null);
    }
  } catch(e) {}
});

updateBadge();
