// background.js — Nemilia Extension v2.2.0
const NEMILIA_META = 'nemilia-ai-workspace';
const MAX_QUEUE    = 200;
// First-run bootstrap only — superseded after first SYNC_WORKFLOWS from the Nemilia app.
// The app pushes its active workflow list via saveLS() → syncWorkflowsToExt() on every save.
const DEFAULT_WORKFLOWS = [
  {id:'wf-research',    name:'Research Suite'},
  {id:'wf-webresearch', name:'Web Research Suite'},
  {id:'wf-marketing',   name:'Marketing Campaign Brief'},
  {id:'wf-competitive', name:'Competitive Intelligence'},
  {id:'wf-content',     name:'Content Calendar'},
  {id:'wf-invest',      name:'Investment Due Diligence'},
  {id:'wf-prd',         name:'Product Spec / PRD'},
];

async function updateBadge() {
  const {captureQueue=[]} = await chrome.storage.local.get(['captureQueue']);
  const n = captureQueue.length;
  chrome.action.setBadgeText({text: n > 0 ? String(n) : ''});
  chrome.action.setBadgeBackgroundColor({color:'#8b6914'});
}

let _cmDebounceTimer = null;
function buildContextMenus() {
  clearTimeout(_cmDebounceTimer);
  _cmDebounceTimer = setTimeout(_buildContextMenusNow, 300);
}
async function _buildContextMenusNow() {
  await chrome.contextMenus.removeAll();
  const {nemiliaWorkflows} = await chrome.storage.local.get(['nemiliaWorkflows']);
  const wfs = nemiliaWorkflows?.length ? nemiliaWorkflows : DEFAULT_WORKFLOWS;

  chrome.contextMenus.create({id:'nem-img-capture', title:'\ud83d\udce5  Send Image to Nemilia', contexts:['image']});

  ['sel','page'].forEach(ctx => {
    const ctxs = ctx==='sel' ? ['selection'] : ['page','frame','link'];
    const rootTitle = ctx==='sel' ? 'Send Selection to Nemilia \u25b8' : 'Send Page to Nemilia \u25b8';
    chrome.contextMenus.create({id:`nem-${ctx}-root`,       title:rootTitle, contexts:ctxs});
    chrome.contextMenus.create({id:`nem-${ctx}-capture`,    parentId:`nem-${ctx}-root`, title:'\ud83d\udce5  Quick Capture',                      contexts:ctxs});
    chrome.contextMenus.create({id:`nem-${ctx}-compose`,    parentId:`nem-${ctx}-root`, title:'\u270f  Open in Compose',                          contexts:ctxs});
    chrome.contextMenus.create({id:`nem-${ctx}-screenshot`, parentId:`nem-${ctx}-root`, title:'\ud83d\udcf7  Capture Screenshot \u2192 Nemilia',   contexts:ctxs});
    chrome.contextMenus.create({id:`nem-${ctx}-sep`,        parentId:`nem-${ctx}-root`, type:'separator',                                          contexts:ctxs});
    chrome.contextMenus.create({id:`nem-${ctx}-wf-lbl`,     parentId:`nem-${ctx}-root`, title:'\u25b6  Run Workflow\u2026', enabled:false,          contexts:ctxs});
    wfs.forEach(wf => chrome.contextMenus.create({
      id:`nem-${ctx}-wf-${wf.id}`, parentId:`nem-${ctx}-root`,
      title:`   ${wf.name}`, contexts:ctxs
    }));
  });
}

chrome.runtime.onInstalled.addListener(() => { buildContextMenus(); updateBadge(); cleanOrphanedSessionImages(); });
cleanOrphanedSessionImages();

async function cleanOrphanedSessionImages() {
  try {
    const all = await chrome.storage.session.get(null);
    const cutoff = Date.now() - 2 * 60 * 60 * 1000;
    const toRemove = Object.keys(all).filter(k => {
      if (!k.startsWith('nem-img-')) return false;
      const ts = all[k]?.capturedAt || 0;
      return ts < cutoff;
    });
    if (toRemove.length) await chrome.storage.session.remove(toRemove);
  } catch(e) {}
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    if (changes.nemiliaWorkflows) buildContextMenus();
    if (changes.captureQueue)     updateBadge();
  }
});

function extractPageContent() {
  const clone = document.body.cloneNode(true);
  ['script','style','noscript','nav','footer','header','aside','iframe','[role="navigation"]']
    .forEach(s => { try { clone.querySelectorAll(s).forEach(el=>el.remove()); } catch(e) {} });
  let text = '';
  for (const sel of ['main','article','[role="main"]','.post-content','.entry-content','[itemprop="articleBody"]','.post-body','.content','#content','#main']) {
    const el = clone.querySelector(sel);
    if (el && (el.innerText||el.textContent||'').trim().length > 200) {
      text = (el.innerText||el.textContent||'').trim(); break;
    }
  }
  if (!text) text = (clone.innerText||clone.textContent||'').trim();
  text = text.replace(/^(skip to (main )?content\n?)/i,'').replace(/\n{3,}/g,'\n\n').replace(/[ \t]+/g,' ').trim();
  const sents = text.match(/[^.!?]+[.!?]+/g) || [];
  const truncated = text.length > 50000;
  return {
    title:     document.title,
    content:   text.slice(0, 50000),
    summary:   sents.slice(0,2).join(' ').slice(0,280),
    wordCount: text.split(/\s+/).filter(Boolean).length,
    truncated: truncated
  };
}

async function fetchImageAsDataUrl(srcUrl) {
  const response = await fetch(srcUrl);
  if (!response.ok) throw new Error('HTTP ' + response.status);
  const mimeType = response.headers.get('content-type')?.split(';')[0]?.trim() || 'image/png';
  const buffer   = await response.arrayBuffer();
  const bytes    = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i += 8192) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
  }
  return 'data:' + mimeType + ';base64,' + btoa(binary);
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const id = info.menuItemId, sel = info.selectionText || '';
  if (id.endsWith('-root') || id.endsWith('-sep') || id.endsWith('-wf-lbl')) return;

  let action = 'capture', workflowId = null;
  if      (id.endsWith('-capture'))    action = 'capture';
  else if (id.endsWith('-compose'))    action = 'compose';
  else if (id.endsWith('-screenshot')) action = 'screenshot';
  else if (id.includes('-wf-'))   { action = 'workflow'; workflowId = id.replace(/nem-(sel|page)-wf-/, ''); }
  else return;

  if (id === 'nem-img-capture' && info.srcUrl) {
    try {
      const dataUrl  = await fetchImageAsDataUrl(info.srcUrl);
      const filename = info.srcUrl.split('/').pop()?.split('?')[0] || 'image.png';
      const payload  = {
        title:      filename.slice(0, 80),
        url:        tab.url || '',
        content:    '',
        summary:    'Image from ' + (tab.title || tab.url || 'page'),
        language:   'en',
        wordCount:  0,
        capturedAt: Date.now(),
        target:     'capture',
        sourceType: 'direct-image',
        dataUrl
      };
      await handleSend(payload, tab.id);
    } catch(e) { console.warn('Nemilia: image fetch failed', e); }
    return;
  }

  if (action === 'screenshot') {
    try {
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
      const payload = {
        title: (tab.title || tab.url || 'Screenshot').slice(0, 80),
        url: tab.url || '',
        content: '',
        summary: 'Screenshot of ' + (tab.title || tab.url || 'page'),
        language: 'en',
        wordCount: 0,
        capturedAt: Date.now(),
        target: 'screenshot',
        sourceType: 'screenshot',
        dataUrl
      };
      await handleSend(payload, tab.id);
    } catch(e) { console.warn('Nemilia: screenshot failed', e); }
    return;
  }

  let payload;
  if (id.startsWith('nem-sel-') && sel) {
    payload = {
      title: sel.slice(0,80) + (sel.length > 80 ? '\u2026' : ''), url: tab.url||'',
      content: sel, summary: sel.slice(0,280), language: 'en',
      wordCount: sel.split(/\s+/).filter(Boolean).length,
      capturedAt: Date.now(), target: action, workflowId, sourceType: 'selection'
    };
  } else {
    try {
      const r = await chrome.scripting.executeScript({ target:{tabId:tab.id}, func: extractPageContent });
      const d = r?.[0]?.result || {};
      payload = {
        title: d.title||tab.title||tab.url, url: tab.url||'',
        content: d.content||'', summary: d.summary||'', language: 'en',
        wordCount: d.wordCount||0, capturedAt: Date.now(),
        target: action, workflowId, sourceType: 'page'
      };
    } catch(e) { console.warn('Nemilia: extract failed', e); return; }
  }
  await handleSend(payload, tab.id);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'SEND_TO_NEMILIA') {
    handleSend(msg.payload, sender.tab?.id)
      .then(r => sendResponse(r))
      .catch(e => sendResponse({ok:false, error:e.message}));
    return true;
  } else if (msg.type === 'EXTRACT_PAGE') {
    chrome.tabs.query({active:true, currentWindow:true}).then(async tabs => {
      const tab = tabs[0];
      if (!tab) return sendResponse({ok:false, error:'No active tab'});
      try {
        if (msg.mode === 'selection') {
          const r = await chrome.scripting.executeScript({
            target: {tabId:tab.id},
            func: () => window.getSelection()?.toString() || ''
          });
          const raw = r?.[0]?.result || '';
          if (!raw.trim()) return sendResponse({ok:false, error:'No text selected'});
          sendResponse({ok:true, data:{
            title: raw.slice(0,80), url: tab.url||'', content: raw,
            summary: raw.slice(0,280),
            wordCount: raw.split(/\s+/).filter(Boolean).length
          }});
        } else if (msg.mode === 'meta') {
          // Lightweight metadata-only extraction — avoids full DOM clone + text parse
          const r = await chrome.scripting.executeScript({
            target: {tabId:tab.id},
            func: () => {
              const text = (document.body?.innerText || document.body?.textContent || '');
              return { title: document.title, wordCount: text.split(/\s+/).filter(Boolean).length };
            }
          });
          const d = r?.[0]?.result || {};
          sendResponse({ok:true, data:{
            title: d.title||tab.title||'', url: tab.url||'',
            content: '', summary: '', wordCount: d.wordCount||0
          }});
        } else {
          const r = await chrome.scripting.executeScript({
            target: {tabId:tab.id}, func: extractPageContent
          });
          const d = r?.[0]?.result || {};
          sendResponse({ok:true, data:{
            title: d.title||tab.title||'', url: tab.url||'',
            content: d.content||'', summary: d.summary||'',
            wordCount: d.wordCount||0
          }});
        }
      } catch(e) { sendResponse({ok:false, error:e.message}); }
    });
    return true;
  } else if (msg.type === 'NEMILIA_IDENTIFIED') {
    chrome.storage.local.set({nemiliaPath: msg.url});
    // [FIX v2.2] Also update the cached tab ID so findNemiliaTab stays accurate
    if (sender.tab?.id) _cachedNemiliaTabId = sender.tab.id;
  } else if (msg.type === 'NEMILIA_APP_READY') {
    // [FIX v2.2] App signals it's fully initialised and listening — NOW drain the queue.
    // This replaces the premature drainQueue() call in onUpdated, which fired before
    // the app's message listener was set up, silently dropping queued items.
    (async () => {
      const _readyTab = sender.tab ?? await findNemiliaTab();
      if (_readyTab) drainQueue(_readyTab, null);
    })();
  } else if (msg.type === 'SYNC_WORKFLOWS') {
    chrome.storage.local.set({nemiliaWorkflows: msg.workflows});
  } else if (msg.type === 'MCP_RELAY') {
    const _senderUrl = sender.url || '';
    const _senderOrigin = sender.origin || '';
    (async () => {
      let allowed = sender.id === chrome.runtime.id || _senderOrigin === 'https://nemilia.com';
      if (!allowed) {
        const {nemiliaPath: _np} = await chrome.storage.local.get(['nemiliaPath']);
        allowed = !!(_np && _senderUrl === _np) ||
                  _senderOrigin === 'http://localhost' ||
                  _senderOrigin === 'https://localhost';
      }
      if (!allowed) { sendResponse({ok:false, error:'Origin not allowed'}); return; }
      const { url, method, headers, body } = msg;
      if (!url || typeof url !== 'string') {
        sendResponse({ok:false, error:'MCP_RELAY: missing url'});
        return;
      }
      fetch(url, {
        method:  method  || 'POST',
        headers: headers || {},
        body:    body    || null,
        // [FIX v2.2] bumped from 15000 to 55000 — aligns with 60s page-side relay timeout
        signal:  AbortSignal.timeout(55000)
      })
        .then(async res => {
          const contentType = res.headers.get('content-type') || '';
          const sessionId   = res.headers.get('mcp-session-id') || null;
          const responseBody = await res.text();
          sendResponse({
            ok:          res.ok,
            status:      res.status,
            contentType,
            sessionId,
            body:        responseBody
          });
        })
        .catch(e => sendResponse({ok:false, error:e.message}));
    })();
    return true;
  }
});

const SESSION_STORAGE_AVAILABLE = !!(chrome.storage && chrome.storage.session);

async function storeImageInSession(key, payload) {
  if (!SESSION_STORAGE_AVAILABLE) return false;
  try {
    await chrome.storage.session.set({[key]: payload});
    return true;
  } catch(e) {
    console.warn('Nemilia: session storage failed:', e.message);
    return false;
  }
}

async function getImageFromSession(key) {
  if (!SESSION_STORAGE_AVAILABLE) return null;
  try {
    const result = await chrome.storage.session.get([key]);
    return result[key] || null;
  } catch(e) { return null; }
}

async function clearImageFromSession(key) {
  if (!SESSION_STORAGE_AVAILABLE) return;
  try { await chrome.storage.session.remove([key]); } catch(e) {}
}

function isImagePayload(payload) {
  return !!(payload.dataUrl && (
    payload.sourceType === 'screenshot' ||
    payload.sourceType === 'page-image' ||
    payload.sourceType === 'direct-image'
  ));
}

async function handleSend(payload, sourceTabId) {
  const nemTab = await findNemiliaTab();

  if (isImagePayload(payload)) {
    if (nemTab) {
      try {
        await chrome.scripting.executeScript({
          target: {tabId: nemTab.id},
          func: (item) => { window.postMessage({type:'NEMILIA_INGEST', ...item}, '*'); },
          args: [payload]
        });
        await showSourceToast(sourceTabId, nemTab.id, '✓ Image sent to Nemilia');
        return {ok:true, queued:false};
      } catch(e) {
        console.warn('Nemilia: image direct-send failed', e);
        return {ok:false, error:e.message};
      }
    } else {
      const sessionKey = 'nem-img-' + Date.now() + '-' + Math.random().toString(36).slice(2,6);
      // Guard against session storage quota (10MB total) — skip if payload is too large
      const _payloadSize = payload.dataUrl ? payload.dataUrl.length : 0;
      const stored = _payloadSize < 5000000 ? await storeImageInSession(sessionKey, payload) : false;
      const placeholder = Object.assign({}, payload);
      delete placeholder.dataUrl;
      if (stored) placeholder.sessionKey = sessionKey;
      await enqueuePayload(placeholder);
      await updateBadge();
      const msg = stored
        ? '📥 Image queued — open Nemilia to receive'
        : _payloadSize >= 5000000
          ? '📥 Image queued (too large for session storage — thumbnail only)'
          : '📥 Image queued (session storage unavailable — limited data only)';
      await showSourceToast(sourceTabId, null, msg);
      return {ok:true, queued:true};
    }
  }

  await enqueuePayload(payload);
  await updateBadge();
  if (!nemTab) {
    await showSourceToast(sourceTabId, null, '📥 Saved — open Nemilia to receive');
    return {ok:true, queued:true};
  }
  return drainQueue(nemTab, sourceTabId);
}

let _queueMutex = Promise.resolve();
async function enqueuePayload(payload) {
  _queueMutex = _queueMutex.then(async () => {
    try {
      payload._queueId = 'q-' + Date.now() + '-' + Math.random().toString(36).slice(2,8);
      const {captureQueue=[]} = await chrome.storage.local.get(['captureQueue']);
      const deduped = captureQueue.filter(c => !(c.url===payload.url && c.sourceType!=='selection'));
      deduped.unshift(payload);
      if (deduped.length > MAX_QUEUE) deduped.length = MAX_QUEUE;
      await chrome.storage.local.set({captureQueue: deduped});
    } catch(e) {
      console.warn('Nemilia: queue storage failed', e.message);
    }
  });
  return _queueMutex;
}

async function showSourceToast(sourceTabId, nemTabId, message) {
  if (!sourceTabId || sourceTabId === nemTabId) return;
  try {
    await chrome.scripting.executeScript({
      target: {tabId: sourceTabId},
      func: (msg) => {
        var old = document.getElementById('__nem_toast__');
        if (old) old.remove();
        var t = document.createElement('div');
        t.id = '__nem_toast__';
        Object.assign(t.style, {
          position:'fixed',bottom:'24px',right:'24px',zIndex:'2147483647',
          background:'#1a3040',color:'#c9a84c',padding:'10px 18px',
          borderRadius:'8px',fontFamily:'Inter,system-ui,sans-serif',
          fontSize:'13px',fontWeight:'600',boxShadow:'0 4px 20px rgba(0,0,0,.3)',
          display:'flex',alignItems:'center',gap:'8px',
          borderLeft:'3px solid #c9a84c',transition:'opacity .4s',opacity:'1',
          maxWidth:'320px',lineHeight:'1.4'
        });
        var ico = document.createElement('span');
        ico.style.cssText = 'font-size:16px;flex-shrink:0';
        ico.textContent = '📥';
        var txt = document.createElement('span');
        txt.textContent = msg;
        t.appendChild(ico); t.appendChild(txt);
        document.body.appendChild(t);
        setTimeout(function(){
          t.style.opacity='0';
          setTimeout(function(){ if(t.parentNode) t.remove(); }, 450);
        }, 3500);
      },
      args: [message]
    });
  } catch(e) {}
}

let _cachedNemiliaTabId = null;
let _lastFullScanTs = 0;

async function findNemiliaTab() {
  if (_cachedNemiliaTabId !== null) {
    try {
      const cached = await chrome.tabs.get(_cachedNemiliaTabId);
      if (cached && !cached.discarded && cached.url) {
        // [FIX v2.2] Re-validate that cached tab is still on the Nemilia URL.
        // Without this, a tab that navigated away would pass the check and drain
        // would fire into the wrong page, silently losing queued items.
        const {nemiliaPath: _np} = await chrome.storage.local.get(['nemiliaPath']);
        if (!_np || cached.url === _np) return cached;
        // Tab navigated away from Nemilia — invalidate cache
        _cachedNemiliaTabId = null;
      }
    } catch(e) { _cachedNemiliaTabId = null; }
  }
  const {nemiliaPath} = await chrome.storage.local.get(['nemiliaPath']);
  const tabs = await chrome.tabs.query({});
  if (nemiliaPath) {
    const t = tabs.find(t => t.url === nemiliaPath);
    if (t) { _cachedNemiliaTabId = t.id; return t; }
  }
  const byTitle = tabs.find(t => t.title === 'Nemilia AI Workspace');
  if (byTitle) { _cachedNemiliaTabId = byTitle.id; return byTitle; }
  // Full file:// tab scan is expensive — throttle to once per 10s
  if (Date.now() - _lastFullScanTs < 10000) return null;
  _lastFullScanTs = Date.now();
  for (const tab of tabs.filter(t => t.url?.startsWith('file://'))) {
    try {
      const r = await chrome.scripting.executeScript({
        target: {tabId:tab.id},
        func: () => document.querySelector('meta[name="application-name"]')?.content
      });
      if (r?.[0]?.result === 'nemilia-ai-workspace') {
        await chrome.storage.local.set({nemiliaPath:tab.url});
        _cachedNemiliaTabId = tab.id;
        return tab;
      }
    } catch(e) {}
  }
  return null;
}

async function drainQueue(nemTab, sourceTabId) {
  const {captureQueue=[]} = await chrome.storage.local.get(['captureQueue']);
  if (!captureQueue.length) return {ok:true, queued:false};
  const imageCount = captureQueue.filter(c => c.sessionKey).length;
  const rehydrated = await Promise.all(captureQueue.map(async item => {
    if (!item.sessionKey) return item;
    const full = await getImageFromSession(item.sessionKey);
    if (full) { await clearImageFromSession(item.sessionKey); return full; }
    const stripped = Object.assign({}, item);
    delete stripped.sessionKey;
    return stripped;
  }));
  try {
    await chrome.scripting.executeScript({
      target: {tabId:nemTab.id},
      func: (items, imgCount) => {
        var i = 0;
        function sendNext() {
          if (i >= items.length) {
            if (imgCount > 0) window.postMessage({type:'NEMILIA_QUEUE_IMAGES_RECEIVED', count:imgCount}, '*');
            return;
          }
          const item = items[i++];
          window.postMessage({type:'NEMILIA_INGEST', ...item}, '*');
          if (i < items.length) requestAnimationFrame(sendNext);
          else if (imgCount > 0) window.postMessage({type:'NEMILIA_QUEUE_IMAGES_RECEIVED', count:imgCount}, '*');
        }
        sendNext();
      },
      args: [rehydrated, imageCount]
    });
    const drainedIds = new Set(rehydrated.map(i => i._queueId).filter(Boolean));
    const {captureQueue: latest=[]} = await chrome.storage.local.get(['captureQueue']);
    await chrome.storage.local.set({captureQueue: latest.filter(i => !drainedIds.has(i._queueId))});
    await showSourceToast(sourceTabId, nemTab.id, '✓ Sent to Nemilia');
    await updateBadge();
    return {ok:true, queued:false};
  } catch(e) { return {ok:true, queued:true, error:e.message}; }
}

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === _cachedNemiliaTabId) _cachedNemiliaTabId = null;
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  if (!tab.url?.startsWith('file://')) return;
  try {
    const r = await chrome.scripting.executeScript({
      target: {tabId}, func: () => document.querySelector('meta[name="application-name"]')?.content
    });
    if (r?.[0]?.result === 'nemilia-ai-workspace') {
      await chrome.storage.local.set({nemiliaPath:tab.url});
      _cachedNemiliaTabId = tabId;
      await chrome.scripting.executeScript({target:{tabId}, files:['content.js']});
      // [FIX v2.2] Do NOT drainQueue here — it fires before the app's message listener
      // is ready, causing items to be postMessage'd into the void and then cleared from
      // storage. Queue is now drained on NEMILIA_APP_READY, which the app posts only
      // after both _initComplete and _authComplete are set.
    }
  } catch(e) {}
});

updateBadge();

// ── API Stream Relay ───────────────────────────────────────────────────────────
chrome.runtime.onConnect.addListener(function(port) {
  if (port.name !== 'nemilia-api-stream') return;
  let _ctrl = null;
  port.onMessage.addListener(async function(msg) {
    if (msg.type !== 'API_STREAM_START') return;
    const _reqId = msg.reqId;                                  // [H1] carry reqId
    _ctrl = new AbortController();
    const _isLocal = /https?:\/\/(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?/.test(msg.url);
    const _timeoutMs = _isLocal ? 300000 : 120000;
    let _timeout = setTimeout(() => _ctrl.abort(), _timeoutMs);
    try {
      const res = await fetch(msg.url, {
        method:  msg.method  || 'POST',
        headers: msg.headers || {},
        body:    msg.body    || null,
        signal:  _ctrl.signal
      });
      if (!res.ok) {
        const errText = await res.text();
        port.postMessage({type:'API_STREAM_ERROR', reqId:_reqId, status:res.status, error:errText.slice(0,300)});
        clearTimeout(_timeout);
        return;
      }
      port.postMessage({type:'API_STREAM_HEADERS', reqId:_reqId, status:res.status});
      const reader  = res.body.getReader();
      const decoder = new TextDecoder();
      while (true) {
        const {done, value} = await reader.read();
        if (done) break;
        clearTimeout(_timeout);
        _timeout = setTimeout(() => _ctrl.abort(), _timeoutMs);
        port.postMessage({type:'API_STREAM_CHUNK', reqId:_reqId, chunk:decoder.decode(value, {stream:true})});
      }
      port.postMessage({type:'API_STREAM_DONE', reqId:_reqId});
    } catch(err) {
      port.postMessage({type:'API_STREAM_ERROR', reqId:_reqId, error:err.name==='AbortError'?'Aborted':err.message});
    } finally {
      clearTimeout(_timeout);
    }
  });
  port.onDisconnect.addListener(function() {
    if (_ctrl) _ctrl.abort();
  });
});
