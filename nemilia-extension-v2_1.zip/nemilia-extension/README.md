# Nemilia — Send to Workspace

Chrome extension companion for **Nemilia AI Workspace v2.1** — the AI OS for your browser.

Captures any page, image, or screenshot and delivers it to your Nemilia workspace. Trigger AI workflows from any site without leaving your current tab.

---

## Requirements

This extension only works alongside the **Nemilia AI Workspace** application (`Nemilia_v2_1.html`). Download it from the same GitHub release or at [nemilia.com](https://nemilia.com).

---

## Installation

1. Unzip `nemilia-extension-v2_1.zip` anywhere on your machine
2. Open `chrome://extensions` in Chrome
3. Enable **Developer mode** (toggle, top right)
4. Click **Load unpacked** → select the `nemilia-extension` folder
5. Open the extension **Details** → enable **Allow access to file URLs**
6. Pin the extension from the 🧩 toolbar icon for quick access

Once installed, open Nemilia — the green **● Extension connected** badge appears in Settings confirming the connection.

---

## What It Does

**Right-click any page:**
- **Quick Capture** — extracts full page text and sends to your Captures inbox
- **Open in Compose** — sends page content directly to Nemilia's Compose view
- **Capture Screenshot** — takes a screenshot of the visible tab and sends for vision analysis
- **Run Workflow →** — submenu lists your saved workflows; select one to run it against the page instantly

**Right-click any image:**
- **Send Image to Nemilia** — sends the image directly to your Captures inbox for vision analysis

**Extension popup (click toolbar icon):**
- **Send Full Page** — captures full page text
- **Send Selection** — captures highlighted text only
- **Capture Screenshot** — captures the visible tab

**Offline queue:** If Nemilia isn't open, items are saved locally and delivered automatically the next time Nemilia opens.

---

## Privacy

This extension does not collect, transmit, or store any data on external servers. Captured content is sent only to the Nemilia tab open in your browser — it never leaves your machine. No analytics, no tracking, no third-party data sharing of any kind.

---

## Permissions

| Permission | Why |
|-----------|-----|
| `activeTab` | Access the current tab to extract text and capture screenshots on user action |
| `scripting` | Inject script to read page text for capture — read only, no page modification |
| `storage` | Persist offline capture queue and sync workflow list |
| `tabs` | Locate the open Nemilia tab to deliver captured items |
| `contextMenus` | Add right-click capture and workflow options to all pages |
| `host_permissions` | Capture content from any page the user chooses; `file://` required for local Nemilia app communication |

---

## Version

**Extension:** v2.1.0  
**Compatible with:** Nemilia AI Workspace v2.1  
**Manifest:** v3  

---

## Links

- **Website:** [nemilia.com](https://nemilia.com)
- **Full documentation:** [github.com/luislopez1212/Nemilia](https://github.com/luislopez1212/Nemilia)
- **Download Nemilia AI Workspace:** [GitHub Releases](https://github.com/luislopez1212/Nemilia/releases)
- **Contact:** [luis@nemilia.com](mailto:luis@nemilia.com)

---

## License

Business Source License 1.1 — free for personal and non-commercial use. Converts to MIT on 2030-02-27.

For commercial licensing: [luis@nemilia.com](mailto:luis@nemilia.com)
